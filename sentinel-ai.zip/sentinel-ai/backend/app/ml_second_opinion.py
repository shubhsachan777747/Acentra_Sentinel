"""Stretch: IsolationForest score shown as a second opinion only."""
