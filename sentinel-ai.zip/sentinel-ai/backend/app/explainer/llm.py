"""Optional LLM explanation from a redacted evidence packet."""
