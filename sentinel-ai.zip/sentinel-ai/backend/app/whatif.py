"""Stretch: trend projection if the error rate keeps rising."""
